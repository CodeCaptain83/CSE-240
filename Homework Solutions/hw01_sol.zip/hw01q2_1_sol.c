#include <stdio.h>

void main() {
	char ch = '+';
	int a = 10, b = 20;
    double f;
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f); break;
	case '-': f = a - b; printf("f = %g\n", f); break;
	case '*': f = a * b; printf("f = %g\n", f); break;
	case '/': f = (double) a / b; printf("f = %g\n", f); break;
	default: printf("invalid operator\n");break;
	}
	ch = '-';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f); break;
	case '-': f = a - b; printf("f = %g\n", f); break;
	case '*': f = a * b; printf("f = %g\n", f); break;
	case '/': f = (double)a / b; printf("f = %g\n", f); break;
	default: printf("invalid operator\n");  break;
	}
	ch = '*';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f); break;
	case '-': f = a - b; printf("f = %g\n", f); break;
	case '*': f = a * b; printf("f = %g\n", f); break;
	case '/': f = (double)a / b; printf("f = %g\n", f); break;
	default: printf("invalid operator\n");  break;
	}
	ch = '/';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f); break;
	case '-': f = a - b; printf("f = %g\n", f); break;
	case '*': f = a * b; printf("f = %g\n", f); break;
	case '/': f = (double)a / b; printf("f = %g\n", f); break;
	default: printf("invalid operator\n");  break;
	}
	ch = '%';
	printf("ch = %c\n", ch);
	switch (ch) {
	case '+': f = a + b; printf("f = %g\n", f); break;
	case '-': f = a - b; printf("f = %g\n", f); break;
	case '*': f = a * b; printf("f = %g\n", f); break;
	case '/': f = (double)a / b; printf("f = %g\n", f); break;
	default: printf("invalid operator\n");  break;
	}
}
