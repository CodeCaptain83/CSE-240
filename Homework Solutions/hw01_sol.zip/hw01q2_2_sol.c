#include <stdio.h>

void main() {
	char ch = ' ';
	int a = 10, b = 20;
    double f;
	int i=0;
    for(i=0;i < 5;i++){
	  ch = getchar();
      printf("ch = %c\n", ch);
      switch (ch) {
        case '+': f = a + b; printf("f = %g\n", f); break;
        case '-': f = a - b; printf("f = %g\n", f); break;
        case '*': f = a * b; printf("f = %g\n", f); break;
        case '/': f = (double) a / b; printf("f = %g\n", f); break;
        default: printf("invalid operator\n");
      }
	  ch = getchar();
    }
}
