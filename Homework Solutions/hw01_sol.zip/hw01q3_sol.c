#include <stdio.h>
#pragma warning(disable : 4996) 

// CSE 240 Spring 2018 Homework 1 Question 3 (20 points)
// Before starting this assignment, please compile and run this program. 
// You will first notice that the program will not compile. Fix the errors and define the error types.
// Next, you will notice that the program is printing incorrect information. Fix the errors and define those error types.

void main(){

	// Problem 1: (4 points)
	// The statement below should cause the program to not compile. Correct the error(s). (2 points).

	int y = 67;

	printf("Integer y is equal to %d\n", y);

	// Define what type of error this is, your answer should replace the space next to "Error Type: " below (2 points).
	// Your answer should be either Syntactic, Semantic, or Contextual.
	printf("Error Type: Syntactic \n\n"); // Reason: missing a part of the declaration is a syntactic error, while using a wrong type is a contextual error.


	// Problem 2: (4 points)
	// Half of 10 is 5, why is the program printing that half of 10 is 0? Correct the error(s) (2 points).

	int x = 10;

	printf("Half of %d is %d\n", x, (x / 2));

	// Define what type of error this is, your answer should replace the space next to "Error Type: " below (2 points).
	// Your answer should be either Syntactic, Semantic, or Contextual.
	printf("Error Type: Semantic \n\n");

     //Problem 3    (2 points)
     //Integer variable y is initialized to 67. However the print statement is giving a different result. Why is it giving that particular character as result?(1 point)
    printf("%c\n",y); 
    // Your answer should be either Syntactic, Semantic, or Contextual. (1 point)
	printf("Error Type: Contextual \n\n");
     
     //Give your explanation here:
     printf("Explanation:It is printing the ASCII value of the number 67 assigned to y\n\n");
	// Problem 4: (2 points)
	// Float variable x has been initialized to 10, why does the program seem to think otherwise? Correct the error(s) (2 points).

	float a = 10.5;

	if (a == 20)
	printf("x is equal to 20.\n");
	if (a > 20)
	printf("x is greater than 20.\n");
	if (a < 20)
	printf("x is less than 20.\n");

	// Define what type of error this is, your answer should replace the space next to "Error Type: " below (2 points).
	// Your answer should be either Syntactic, Semantic, or Contextual.
	printf("Error Type: Semantic \n\n");


	// Problem 5: (4 points)
	// Surely, 10 is an even number. Why is the program printing that 10 is an odd number? Correct the error(s) ( points).

	x = 10;

	if (x % 2 == 0)
		printf("%d is an even number.\n", x);
	if (x % 2 != 0)
		printf("%d is an odd number.\n", x);

	// Define what type of error this is, your answer should replace the space next to "Error Type: " below (2 points).
	// Your answer should be either Syntactic, Semantic, or Contextual.
	printf("Error Type: Semantic \n\n");


	// Problem 6: (4 points)
	// This bit of code is meant to print "Hello World!". Correct the error(s) (2 points).

	printf("Hello World!\n");

	// Define what type of error this is, your answer should replace the space next to "Error Type: " below (2 points).
	// Your answer should be either Syntactic, Semantic, or Contextual.
	printf("Error Type: Contextual \n\n");
}
