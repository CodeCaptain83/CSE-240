#include "Animals.h"

Animals::Animals(Category animal_category, string animal_breed, Subcategory animal_subcategory, string animal_name, int animal_age) {
	category=animal_category;
    breed = animal_breed;
    subcategory=animal_subcategory;
    name = animal_name;
	age = animal_age;
}

Category Animals::getCategory() {
	return category;
}

string Animals::getBreed() {
	return breed;
}

string Animals::getName() {
	return name;
}

Subcategory Animals::getSubcategory() {
	return subcategory;
}

int Animals::getAge() {
	return age;
}

