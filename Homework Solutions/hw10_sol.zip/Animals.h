#ifndef _ANIMALS_H_
#define _ANIMALS_H_

#include <string>
using namespace std;

enum Category { canidae = 0, felidae };
enum Subcategory { dog = 0, cat };

class Animals {
private:
    Category category;
    Subcategory subcategory;
	string name, breed; // private local variables
	int age;

public:
	Animals(Category animal_category, string animal_breed, Subcategory animal_subcategory, string animal_name, int animal_age); // constructor

	// accessor methods
	Category getCategory();
	string getBreed();
	Subcategory getSubcategory();
	string getName();
	int getAge();

	friend void changeAge(Animals* animal, int age);

	virtual string toString(){ 
		
		return string();
	}
};

#endif // _ANIMALS_H_
