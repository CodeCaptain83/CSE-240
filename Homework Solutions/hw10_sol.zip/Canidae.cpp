#include "Canidae.h"
#include "Animals.h"

#include <iostream>


string Canidae::getCanidaeName() {
      string Name=getName();
	return Name;
}

int Canidae::getCanidaeAge() {
    int Age=getAge();
	return Age;
}

string Canidae::getCanidaeBreed(){
      string breed=getBreed();
      return breed; }
       
string Canidae::toString() 
{
	string res = "Breed:" + getBreed() + '\n';
	res+= "Category: Canidae" + '\n';
	return res;
	
}

