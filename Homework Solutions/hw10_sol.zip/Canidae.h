#ifndef _CANIDAE_H_
#define _CANIDAE_H_

#include "Animals.h"

class Canidae : public Animals {
public:
	Canidae(Category animal_category, string animal_breed, Subcategory animal_subcategory, string animal_name, int animal_age) : Animals(animal_category,  animal_breed,  animal_subcategory,animal_name,  animal_age){}
    
    // accessor methods
	string getCanidaeName();
	int getCanidaeAge();
	string getCanidaeBreed();
    
    virtual string toString(); 
};

#endif // _CANIDAE_H_
