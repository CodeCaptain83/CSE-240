#include "Felidae.h"
#include "Cat.h"

#include <iostream>

string Cat::toString()
{
	string res = string();
	res += "Name: " + getFelidaeName() + '\n' + "Age: " + to_string(getFelidaeAge()) + '\n'+"Breed: " + getFelidaeBreed() + '\n' +"Category: Felidae"+'\n'+ "Subcategory: Cat" + '\n';
	return res;
}
