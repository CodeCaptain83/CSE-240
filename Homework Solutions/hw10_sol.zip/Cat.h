#ifndef _CAT_H_
#define _CT_H_

#include "Felidae.h"

class Cat : public Felidae {
public:
	Cat(Category animal_category,string animal_breed,Subcategory animal_subcategory, string animal_name, int animal_age) : Felidae(animal_category,animal_breed,animal_subcategory, animal_name, animal_age){}

	string toString();
};

#endif // _CAT_H_
