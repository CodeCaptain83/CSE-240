#include "Container.h"

// Constructor for Container class
Container::Container(){
	animals = NULL;
	next = NULL;
}
