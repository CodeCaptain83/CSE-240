#ifndef _CONTAINER_H_
#define _CONTAINER_H_

#include "Animals.h"

class Container {
public:
	Animals *animals;
	Container *next;
	Container(); // constructor
};

#endif // _CONTAINER_H_
