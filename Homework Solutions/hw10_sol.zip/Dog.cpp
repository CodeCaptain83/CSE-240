#include "Canidae.h"
#include "Dog.h"

#include <iostream>

string Dog::toString()
{   
	string res = string();
	res += "Name: " + getCanidaeName() + '\n' + "Age: " + to_string(getCanidaeAge()) +'\n'+ "Breed: " + getCanidaeBreed() + '\n' +"Category: Canidae"+'\n' +"Subcategory: Dog" + '\n';
	return res;

}
