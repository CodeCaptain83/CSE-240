#ifndef _DOG_H_
#define _DOG_H_

#include "Canidae.h"

class Dog : public Canidae {
public:
         
	Dog(Category animal_category,string animal_breed,Subcategory animal_subcategory, string animal_name, int animal_age) : Canidae(animal_category,animal_breed,animal_subcategory,animal_name, animal_age){}
	virtual string toString();
};

#endif // _DOG_H_
