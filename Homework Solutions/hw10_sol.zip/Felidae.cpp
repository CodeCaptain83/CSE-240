#include "Felidae.h"

#include <iostream>


string Felidae::getFelidaeName() {
      string felidae_name=getName();
	return felidae_name;
}

int Felidae::getFelidaeAge() {
    int felidae_age=getAge();
	return felidae_age;
}

string Felidae::getFelidaeBreed(){
      string breed=getBreed();
      return breed; }
      
string Felidae::toString()
{
	string res = "Breed: " + getBreed() + '\n';
	res += "Category: Felidae" + '\n';
	return res;

}
