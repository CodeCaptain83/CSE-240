#ifndef _FELIDAE_H_
#define _FELIDAE_H_

#include "Animals.h"

class Felidae : public Animals {
public:
	Felidae(Category animal_category, string animal_breed, Subcategory animal_subcategory, string animal_name, int animal_age) : Animals( animal_category,  animal_breed,  animal_subcategory,  animal_name, animal_age){}

    // accessor methods
	string getFelidaeName();
	int getFelidaeAge();
	string getFelidaeBreed();
    
    virtual string toString();
};

#endif // _FELIDAE_H_
