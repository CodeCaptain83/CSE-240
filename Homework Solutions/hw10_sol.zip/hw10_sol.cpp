// CSE 240
// READ BEFORE YOU START:
// You are given a partially completed program that creates a list of animals.
// Each animal has the corresponding information: Category, breed, subcategory, name and age.
// In the Animals.h file, you will find the definition for this enum 'category'and 'subcategory'.
// Animals on the list can be 2 different 'categories' : either a canidae or a felidae.
// The classes Dog and Cat are subclasses of the Canidae and Felidae class respectively.
// Both of these classes will have their own use of the virtual toString method.
//
// To begin, you should trace through the given code and understand how it works.
// Please read the instructions above each required function and follow the directions carefully.
// If you modify any of the given code, the return types, or the parameters, you risk failing the automated test cases.
//
// You are to assume that all input is valid:
// Valid name:	String containing alphabetical letters beginning with a capital letter
// Valid breed: String containing alphabetical letters beginning with a capital letter
// All input will be a valid length and no more than the allowed amount of memory will be used

#include "Container.h"
#include "Animals.h"
#include "Canidae.h"
#include "Felidae.h"
#include "Dog.h"
#include "Cat.h"

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// forward declarations
void flush();
void branching(char);
void helper(char);
void add_animal(Category, string, Subcategory, string, int); // 5 points
Animals* search_animal(Category, string, Subcategory, string, int);
void remove_animal(Category, string, Subcategory, string, int);

int listCount();
void print_all(); // 5 points
void sort(); // 10 points
void save(string); // 5 points
void load(string); // 5 points

Container* list = NULL; // global list

int main()
{

	//load("Animals.txt");

	char ch = 'i';

	do {
		cout << "Please enter your selection" << endl;
		cout << "\ta: add a new animal to the list" << endl;
		cout << "\tc: change the age of an animal" << endl;
		cout << "\tr: remove an animal from the list" << endl;
		cout << "\ts: sort the list of animals" << endl;
		cout << "\tp: print all animals on the list" << endl;
		cout << "\tq: quit and save list of animals" << endl;
		cin >> ch;
		flush();
		branching(ch);
	} while (ch != 'q');

	save("Animals.txt");

	list = NULL;
	return 0;
}

void flush()
{
	int c;
	do c = getchar(); while (c != '\n' && c != EOF);
}

void branching(char c)
{
	switch (c) {
	case 'a':
	case 'c':
	case 'r':
	case 'p':
		helper(c);
		break;
	case 's':
		sort();
		break;
	case 'q':
		break;
	default:
		printf("\nInvalid input!\n\n");
	}
}

// The helper function is used to determine how much data is needed and which function to send that data to.
// It uses pointers and values that are returned from some functions to produce the correct ouput.
// There is no implementation needed here, but you should study this function and know how it works.
// It is always helpful to understand how the code works before implementing new features.
// Do not change anything in this function or you risk failing the automated test cases.
void helper(char c)
{
	string breed, name;
	int age;
	Category category;
	Subcategory subcategory;
	int category_check = -1, subcategory_check = -1;

	if (c == 'p') {
		print_all();
	}

	else
	{
		cout << endl << "Please enter the animal's name: " << endl;
		cin >> name; flush();
		cout << endl << "Please enter the animal's age: " << endl;
		cin >> age; flush();
		cout << "Please enter the animal's breed: " << endl;
		cin >> breed; flush();


		while (!(category_check == 0 || category_check == 1))
		{
			cout << endl << "Please select one of the following: " << endl;
			cout << "0. Candide " << endl;
			cout << "1. Felidae" << endl;
			cin >> category_check;
		}

		category = (Category)category_check;

		while (!(subcategory_check == 0 || subcategory_check == 1))
		{
			cout << endl << "Please select one of the following: " << endl;
			cout << "0. Dog " << endl;
			cout << "1. Cat" << endl;
			cin >> subcategory_check;
		}
		subcategory = (Subcategory)subcategory_check;

		Animals* animal_result = search_animal(category, breed, subcategory, name, age);

		if (c == 'a') // add animal
		{
			if (animal_result == NULL)
			{
				add_animal(category, breed, subcategory, name, age);
				cout << endl << "Animal added." << endl << endl;
			}
			else
				cout << endl << "Animal already on list." << endl << endl;
		}
		else if (c == 'c') // change animal age
		{
			if (animal_result == NULL)
			{
				cout << endl << "Animal not found." << endl << endl;
				return;
			}

			cout << endl << "Please enter the new age for this animal: " << endl;
			cin >> age; flush();

			changeAge(animal_result, age);

			cout << endl << "Animal's age changed." << endl << endl;
		}
		else if (c == 'r') // remove animal
		{
			if (animal_result == NULL)
			{
				cout << endl << "Animal not found." << endl << endl;
				return;
			}

			remove_animal(category, breed, subcategory, name, age);
			cout << endl << "Animal removed from the list." << endl << endl;
		}
	}
}

// Q3: Add Animal
// This function will be used to add a new animal to the tail of the global linked list.
// You will need to use the enums �category� and 'subcategory' variable to determine which constructors to use.
// Remember that search is called before this function, therefore, the new animal is not on the list.
void add_animal(Category category, string breed, Subcategory subcategory, string name, int age)
{
	Container* new_container = new Container();

	if (category == canidae)
		new_container->animals = new Dog(category, breed, subcategory, name, age);
	else
		new_container->animals = new Cat(category, breed, subcategory, name, age);

	new_container->next = NULL;

	if (list == NULL)
	{
		list = new_container;
		return;
	}

	Container* container_traverser = list->next;
	Container* container_follower = list;

	while (container_traverser != NULL)
	{
		container_follower = container_traverser;
		container_traverser = container_traverser->next;
	}

	container_follower->next = new_container;
}

// No implementation needed here, however it may be helpful to review this function
Animals* search_animal(Category category, string breed, Subcategory subcategory, string name, int age)
{
	Container* container_traverser = list;

	while (container_traverser != NULL)
	{
		if (container_traverser->animals->getName() == name
			&& container_traverser->animals->getBreed() == breed
			&& container_traverser->animals->getCategory() == category
			&& container_traverser->animals->getSubcategory() == subcategory)
			return container_traverser->animals;

		container_traverser = container_traverser->next;
	}

	return NULL;
}

void remove_animal(Category category, string breed, Subcategory subcategory, string name, int age)
{
	Container* to_be_removed;

	if (list->animals->getName() == name
		&& list->animals->getBreed() == breed
		&& list->animals->getCategory() == category
		&& list->animals->getSubcategory() == subcategory)
	{
		to_be_removed = list;
		list = list->next;
		delete to_be_removed->animals;
		delete to_be_removed;
		return;
	}

	Container* container_traverser = list->next;
	Container* container_follower = list;

	while (container_traverser != NULL)
	{
		if (list->animals->getName() == name
			&& list->animals->getBreed() == breed
			&& list->animals->getCategory() == category
			&& list->animals->getSubcategory() == subcategory)
		{
			to_be_removed = container_traverser;
			container_traverser = container_traverser->next;
			container_follower->next = container_traverser;
			delete to_be_removed->animals;
			delete to_be_removed;
			return;
		}
		container_follower = container_traverser;
		container_traverser = container_traverser->next;
	}
}

// Q4b: Change age function
void changeAge(Animals* animal, int age) {
	animal->age = age;
}
// Q5: Sort function (10 points)
// This function should sort the list of animals recursively based on the name and age of the animal, respectively. 
// The user enters �n� or �a� and selects the type of sorting. Any other invalid input should be checked. 
// The sort function can be verified using print_all function. You can use selection, merge, or quick short. 
// Hint: The textbook has recursive program for all these algorithms.
void recursiveSort(Container * animalList, char sortType) 
{
	Container * min = animalList;
	Container * traverser;

	if (animalList == NULL) // base case
		return;

	for (traverser = animalList; traverser != NULL; traverser = traverser->next) {
		if ((traverser->animals->getAge() < min->animals->getAge() && (sortType =='a')) ||
			(traverser->animals->getName() < min->animals->getName() && (sortType == 'n'))) {
			min = traverser;
		}
	}
	if (animalList != min)
	{
		Animals * temp = animalList->animals;
		animalList->animals = min->animals;
		min->animals = temp;
	}
	recursiveSort(animalList->next, sortType); //size n-1 
}
void sort()
{
	char ch;
	do {
		printf("Please enter sorting method a (by age) or n (by name)\n");
		ch = tolower(getchar());
		getchar();
		if (ch != 'n'  && ch != 'a') {
			printf("Invalid option. Please try again.\n");
		}
	} while (ch != 'n'  && ch != 'a');
	if (ch == 'a') {
		recursiveSort(list, 'a');
	}
	if (ch == 'n') {
		recursiveSort(list, 'n');
	}
	cout << "The sorting has been done" << endl << endl;

}

int listCount()
{
	Container *container_traverser = list;
	int cnt = 0;
	while (container_traverser != NULL)
	{
		cnt++;
		container_traverser = container_traverser->next;
	}
	return cnt;
}
// Q6: print function
// This function should print the number of animals on the list first 
// If there is no animal on the list, it should print out �List is empty�. 
// You can write the function to calculate the number of animals on the list. 
// Then, the information of each animal should be printed using the toString method. 
void print_all()
{
	Container *container_traverser = list;

	if (list == NULL)
	{
		cout << endl << "List is empty!" << endl << endl;
		return;
	}

	cout << "The number of animals in the list is: " << listCount() << endl << endl;
	while (container_traverser != NULL)
	{
		cout << container_traverser->animals->toString();
		cout << endl;
		container_traverser = container_traverser->next;
	}
}
// Q7a: Save (5 points)
// Save the linked list of animals to a file using ofstream.
// You will need to come up with a way to store the amount of Containers in linked list.
// Hint: You may want to cast the enum 'type' to an int before writing it to the file.
void save(string fileName)
{
	int count = 0;
	Container* container_traverser = list;

	while (container_traverser != NULL) // count number of Containers in linked list
	{
		container_traverser = container_traverser->next;
		count++;
	}

	ofstream myfile;
	myfile.open(fileName);

	if (myfile.is_open())
	{
		container_traverser = list;
		myfile << count << endl;

		while (container_traverser != NULL)
		{
			myfile << container_traverser->animals->getName() << endl;
			myfile << (int)container_traverser->animals->getAge() << endl;
			myfile << container_traverser->animals->getBreed() << endl;
			myfile << (int)container_traverser->animals->getCategory() << endl;
			myfile << (int)container_traverser->animals->getSubcategory() << endl;

			container_traverser = container_traverser->next;
		}
		myfile.close();
	}

}

// Q7b: Load (5 points)
// Load the linked list of Animals from a file using ifstream.
// You will need to create the linked list in the same order that is was saved to a file.
// You will need to create a new node for the linked list, then add it to the tail of the list. 
// Hint: If you casted the enum 'type' to an int, you will need to cast it back to a 'Type'.
// You will use the 'type' variable read from the file to determine which constructor to use.
void load(string fileName)
{
	ifstream myfile;
	myfile.open(fileName);

	if (myfile.is_open())
	{
		int category_as_int, subcategory_as_int, age, count = 0;
		string name, breed;
		Category category;
		Subcategory subcategory;

		Container* container_traverser = list;

		myfile >> count;

		for (int i = 0; i < count; i++)
		{
			Container* new_node = new Container();

			myfile >> name;
			myfile >> age;
			myfile >> breed;
			myfile >> category_as_int;
			myfile >> subcategory_as_int;


			category = (Category)category_as_int;
			subcategory = (Subcategory)subcategory_as_int;
			if (category == canidae)
				new_node->animals = new Dog(category, breed, subcategory, name, age);
			else
				new_node->animals = new Cat(category, breed, subcategory, name, age);

			new_node->next = NULL;

			if (list == NULL)
			{
				new_node->next = list;
				list = new_node;
			}
			else
			{
				container_traverser = list;
				while (container_traverser->next != NULL)
					container_traverser = container_traverser->next;
				container_traverser->next = new_node;
			}
		}
		myfile.close();
	}
}
